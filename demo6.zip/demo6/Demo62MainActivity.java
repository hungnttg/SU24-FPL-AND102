package com.hnq40.myapplication55.demo6;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import com.hnq40.myapplication55.R;

public class Demo62MainActivity extends AppCompatActivity {
    Button btnStart,btnStop,btnBackgroundService;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo62_main);
        btnStart=findViewById(R.id.demo62BtnStart);
        btnStop=findViewById(R.id.demo62BtnStop);
        btnStart.setOnClickListener(v->{
            startService(new Intent(Demo62MainActivity.this,
                    ForcegroundService.class));
        });
        btnStop.setOnClickListener(v->{
            startService(new Intent(Demo62MainActivity.this,
                    ForcegroundService.class));
        });
        btnBackgroundService=findViewById(R.id.demo62BtnBackgroundService);
        btnBackgroundService.setOnClickListener(v->{
            startService(new Intent(Demo62MainActivity.this,
                    BackgroundService.class));
        });
    }
}