package com.hnq40.myapplication55.demo6;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.os.Bundle;
import android.widget.Button;

import com.hnq40.myapplication55.R;

public class Demo61MainActivity extends AppCompatActivity {
    Button btn1;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo61_main);
        btn1=findViewById(R.id.demo61Btn1);
        btn1.setOnClickListener(v->{
            sendNotification();
        });
    }

    @SuppressLint("MissingPermission")
    private void sendNotification(){
        //tao 1 notification
        NotificationCompat.Builder builder=new NotificationCompat.Builder(this,App.CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setContentTitle("Thong bao")
                .setContentText("Thong bao cu the")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);
        NotificationManagerCompat notificationManager=
                NotificationManagerCompat.from(this);

        notificationManager.notify(1,builder.build());
    }
}