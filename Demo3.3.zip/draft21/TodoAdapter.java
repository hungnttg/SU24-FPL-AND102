package com.example.myapplication.draft21;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.myapplication.R;

import java.util.List;

public class TodoAdapter extends
        RecyclerView.Adapter<TodoAdapter.TodoViewHolder> {

    private List<Todo> todoList;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onDeleteClick(int position);
        void onEditClick(int position);
        void onStatusChange(int position, boolean isDone);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }
    //-----demo3------
    private Context context;
    private TodoDAO todoDAO;
    public TodoAdapter(Context context, List<Todo> todoList, TodoDAO todoDAO) {
        this.context = context;
        this.todoList = todoList;
        this.todoDAO = todoDAO;
    }
    //end demo3-------
    public TodoAdapter(List<Todo> todoList) {
        this.todoList = todoList;
    }

    @NonNull
    @Override
    public TodoViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.draft21_item_todo,
                        parent, false);
        return new TodoViewHolder(view, listener);
    }

    @Override
    public void onBindViewHolder(
            @NonNull TodoViewHolder holder,
            @SuppressLint("RecyclerView") int position) {
        Todo currentTodo = todoList.get(position);
        holder.tvToDoName.setText(currentTodo.getTitle());
        holder.checkBox.setChecked(currentTodo.getStatus() == 1);

        holder.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView,
                                         boolean isChecked) {
                if (listener != null) {
                    listener.onStatusChange(position, isChecked);
                }
            }
        });
        //----demo3---
        holder.btnDelete.setOnClickListener(v->{
            showDeleteConfirmDialog(holder.getAdapterPosition());
        });
        //end demo3------
        //---start demo3.4
        holder.btnEdit.setOnClickListener(v ->
                showEditDialog(holder.getAdapterPosition()));
        //----end demo3.4
    }

    @Override
    public int getItemCount() {
        return todoList.size();
    }
    //-----demo3------
    private void showDeleteConfirmDialog(int position) {
        new AlertDialog.Builder(context)
                .setTitle("Xác nhận xóa")
                .setMessage("Bạn có chắc chắn muốn xóa công việc này không?")
                .setPositiveButton("Xóa",
                        (dialog, which) -> deleteTodoItem(position))
                .setNegativeButton("Hủy", null)
                .show();
    }
    private void deleteTodoItem(int position) {
        Todo todo = todoList.get(position);
        todoDAO.deleteTodo(todo.getId());
        todoList.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, todoList.size());
    }
    ///----------end demo3----
    //--------Start demo3.4--
    private void showEditDialog(int position) {
        Todo todo = todoList.get(position);

        View dialogView = LayoutInflater.from(context)
                .inflate(R.layout.draft33_dialog_edit_todo, null);
        EditText etTodoTitle = dialogView.findViewById(R.id.etTodoTitle);
        EditText etTodoContent = dialogView.findViewById(R.id.etTodoContent);
        EditText etTodoDate = dialogView.findViewById(R.id.etTodoDate);
        EditText etTodoType = dialogView.findViewById(R.id.etTodoType);
        Button btnUpdate = dialogView.findViewById(R.id.btnUpdate);
        Button btnCancel = dialogView.findViewById(R.id.btnCancel);

        etTodoTitle.setText(todo.getTitle());
        etTodoContent.setText(todo.getContent());
        etTodoDate.setText(todo.getDate());
        etTodoType.setText(todo.getType());

        AlertDialog dialog = new AlertDialog.Builder(context)
                .setView(dialogView)
                .create();

        btnUpdate.setOnClickListener(v -> {
            String newTitle = etTodoTitle.getText().toString();
            String newContent = etTodoContent.getText().toString();
            String newDate = etTodoDate.getText().toString();
            String newType = etTodoType.getText().toString();

            if (!newTitle.isEmpty() && !newContent.isEmpty()
                    && !newDate.isEmpty() && !newType.isEmpty()) {
                todo.setTitle(newTitle);
                todo.setContent(newContent);
                todo.setDate(newDate);
                todo.setType(newType);
                todoDAO.updateTodo(todo);
                notifyItemChanged(position);
                dialog.dismiss();
            } else {
                Toast.makeText(context,
                        "Vui lòng nhập đầy đủ thông tin",
                        Toast.LENGTH_SHORT).show();
            }
        });

        btnCancel.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }
    ///------End 3.4

    public static class TodoViewHolder extends RecyclerView.ViewHolder {
        public TextView tvToDoName;
        public Button btnEdit, btnDelete;
        public CheckBox checkBox;

        public TodoViewHolder(View itemView, final OnItemClickListener listener) {
            super(itemView);
            tvToDoName = itemView.findViewById(R.id.tvToDoName);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
            checkBox = itemView.findViewById(R.id.checkBox);

            btnDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            //listener.onDeleteClick(position);
                            //---demo3---

                            //---end demo3---
                        }
                    }
                }
            });

            btnEdit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            //dong doan code nay phuc vu demo3.4
                            //listener.onEditClick(position);
                        }
                    }
                }
            });
        }
    }
}
