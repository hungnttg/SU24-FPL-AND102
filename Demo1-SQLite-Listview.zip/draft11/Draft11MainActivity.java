package com.example.myapplication.draft11;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.example.myapplication.R;
import com.example.myapplication.draft21.TodoAdapter;

import java.util.List;

public class Draft11MainActivity extends AppCompatActivity {
    private ListView listView;
    private TodoAdapterListview adapter;
    private List<Todo> todoList;
    private TodoDatabaseHelper dbHelper;

    private EditText editTextTitle;
    private EditText editTextDescription;
    private Button buttonAddTodo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_draft11_main);
        listView = findViewById(R.id.draft11_listView);

        listView = findViewById(R.id.draft11_listView);
        editTextTitle = findViewById(R.id.draft11_editTextTitle);
        editTextDescription = findViewById(R.id.draft11_editTextDescription);
        buttonAddTodo = findViewById(R.id.draft11_buttonAddTodo);

        dbHelper = new TodoDatabaseHelper(this);
        todoList = dbHelper.getAllTodos();

        adapter = new TodoAdapterListview(this, todoList);
        listView.setAdapter(adapter);

        buttonAddTodo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = editTextTitle.getText().toString();
                String description = editTextDescription.getText().toString();
                if (!title.isEmpty() && !description.isEmpty()) {
                    Todo newTodo = new Todo(title, description);
                    dbHelper.addTodo(newTodo);
                    todoList.add(newTodo);
                    adapter.notifyDataSetChanged();
                    editTextTitle.setText("");
                    editTextDescription.setText("");
                }
            }
        });
    }
}