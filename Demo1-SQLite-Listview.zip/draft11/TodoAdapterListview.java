package com.example.myapplication.draft11;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;


import java.util.List;
import com.example.myapplication.R;

public class TodoAdapterListview extends ArrayAdapter<Todo> {

    public TodoAdapterListview(Context context, List<Todo> todos) {
        super(context, 0, todos);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext())
                    .inflate(R.layout.draft11_item_todo, parent, false);
        }

        Todo todo = getItem(position);

        TextView title = convertView.findViewById(R.id.draft11_item_todoTitle);
        TextView description = convertView.findViewById(R.id.draft11_item_todoDescription);

        title.setText(todo.getTitle());
        description.setText(todo.getDescription());

        return convertView;
    }
}